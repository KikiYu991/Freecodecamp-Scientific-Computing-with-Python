# Budget App

A Budget App project with simple mechanics used for portfolio purposes 
