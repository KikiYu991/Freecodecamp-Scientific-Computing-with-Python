# Arithmetic Formatter

A Arithmetic Formatter project with simple mechanics used for portfolio purposes 
