# Read README.md before proceeding 
from arithmetic_arranger import arithmetic_arranger
from unittest import main


print(arithmetic_arranger(["52 + 988", "9033 - 2", "76 + 88", "560 + 49"]))


# Run unit tests automatically
main(module='test_module', exit=False)
