# Probability Calculator

A Probability Calculator project with simple mechanics used for portfolio purposes 
