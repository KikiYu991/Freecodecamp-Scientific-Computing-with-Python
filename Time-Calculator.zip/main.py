# Read README.md before proceeding 
from time_calculator import add_time
from unittest import main


print(add_time("9:06 PM", "5:06"))


# Run unit tests automatically
main(module='test_module', exit=False)