# Time Calculator

A Time Calculator project with simple mechanics used for portfolio purposes 
