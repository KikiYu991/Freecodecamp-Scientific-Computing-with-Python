# Polygon Area Calculator

A Polygon Area Calculator project with simple mechanics used for portfolio purposes 
